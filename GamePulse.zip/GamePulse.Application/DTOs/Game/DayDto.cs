﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamePulse.Application.DTOs.Game
{
    public class DayDto
    {
        public DateTime Day { get; set; }

        public int ReleasesCount { get; set; }
    }
}
